# Better Gnomio

## work in progress

Used urls:
*://zs2ti.gnomio.com/* - for working on site

Used libs:
https://code.jquery.com/jquery-3.6.1.min.js - jQuery